Name of application :ELANCO_IT_VetAssistDermatology
Author :NIDHI RAJKOTIYA (C231025) 
IT Responsible Org :Elanco IT 
Development Languages: Node.js
